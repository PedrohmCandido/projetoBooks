import BookList from "../components/BookList";

function Home() {
    return(
        <div>
            <BookList></BookList>
        </div>
    )
}

export default Home;